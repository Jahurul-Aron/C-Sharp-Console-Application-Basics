﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InterfaceApp
{
   public class Customer :ICustomer2
    {
        public void Print2()
        {
            Console.WriteLine("Print2");
            Console.ReadKey();

        }
        public void Print1()
        {
            Console.WriteLine("Print1");
            Console.ReadKey();
        }
    }
}
