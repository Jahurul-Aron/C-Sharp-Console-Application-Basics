﻿using System;


namespace InterfaceApp
{
    
   public class Program
    {
       public static void Main()
        {
            Customer c1 = new Customer();
            c1.Print1();
            c1.Print2();
            
        }
    }
}
