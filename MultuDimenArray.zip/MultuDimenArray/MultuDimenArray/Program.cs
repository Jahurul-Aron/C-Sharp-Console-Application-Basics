﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MultuDimenArray
{
    class Program
    {
        static void Main(string[] args)
        {
            //int[,] array =
            //{
            //    {1,3,4,5,4,5 },
            //    {1,3,4,5,4,5 },
            //    {6,3,4,5,4,5 },
            //    {1,3,4,5,4,5 }


            //};

            //Console.WriteLine(array[2, 0]);
            // My goal  is to add two array
            // Here is the first Array print it
            Console.Write("Row Number=");
            int rows = int.Parse(Console.ReadLine());
            Console.Write("\nColum Number=");
            int columns = int.Parse(Console.ReadLine());
            Console.WriteLine();
            Console.WriteLine(new string('-',50));
            int[,] array = new int[rows, columns];
            //for (int row = 0; row < array.GetLength(0); row++)
            for (int row = 0; row < rows; row++)

            {
                //for (int col = 0; col < array.GetLength(1); col++)
                for (int col = 0; col < columns; col++)
                {
                    Console.Write("Array[{0 },  {1 }]=",row,  col);
                    array[row, col] = int.Parse(Console.ReadLine());
                }
            }
            for (int row = 0; row < rows; row++)

            {
                //for (int col = 0; col < array.GetLength(1); col++)
                for (int col = 0; col < columns; col++)
                {
                    Console.Write("{0}   ",  array[row,  col]);
                   
                }
                Console.WriteLine();
            }
            Console.WriteLine(new string('-',60));
            // Here is the Second Array print it
            //Console.Write("Row Number=");
            //int rows2 = int.Parse(Console.ReadLine());
            //Console.Write("\nColum Number=");
            //int columns2 = int.Parse(Console.ReadLine());
            Console.WriteLine();
            Console.WriteLine(new string('-', 50));
            int[,] array2 = new int[rows, columns];
            //for (int row = 0; row < array.GetLength(0); row++)
            for (int row = 0; row < rows; row++)

            {
                //for (int col = 0; col < array.GetLength(1); col++)
                for (int col = 0; col < columns; col++)
                {
                    Console.Write("Array[{0 },  {1 }]=", row, col);
                    array2[row, col] = int.Parse(Console.ReadLine());
                }
            }
            for (int row = 0; row < rows; row++)

            {
                //for (int col = 0; col < array.GetLength(1); col++)
                for (int col = 0; col < columns; col++)
                {
                    Console.Write("{0}   ", array2[row, col]);

                }
                Console.WriteLine();

            }
                Console.WriteLine(new string('-', 60));

            //Now add two array in 
            int[,] result = new int[rows, columns];
            //for (int row = 0; row < array.GetLength(0); row++)
            for (int row = 0; row < rows; row++)

            {
                //for (int col = 0; col < array.GetLength(1); col++)
                for (int col = 0; col < columns; col++) 
                {
                    
                    result[row, col] = array[row, col]+array2[row, col];
                    Console.Write("{0} ",result[row, col]);
                }
                Console.WriteLine();
            }
            Console.ReadKey();
        }
    }
}
