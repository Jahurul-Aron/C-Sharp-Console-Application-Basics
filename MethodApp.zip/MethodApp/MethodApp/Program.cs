﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
                    
namespace MethodApp
{
    class Program
    {
        static void Main(string[] args)
        {
            string one1 = Console.ReadLine();
            string two1 = Console.ReadLine();

            

            Console.WriteLine(comparestring(one1,two1));
            Console.ReadKey();
        }

        static bool comparestring(string one, string two)
            
        {
            bool isqual = true;
            if (one.Length == two.Length)
            {
                for (int i = 0; i < one.Length; i++)
                {
                    if (one != two)
                    {
                        isqual = false;
                        break;

                    }
                }
                        return isqual;
			}
                else { isqual = false;
                    return isqual;
            }
           

        }
        
        
            
        }

    
}
